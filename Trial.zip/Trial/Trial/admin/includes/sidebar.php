<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
					<li><a href="#"><i class="fa fa-files-o"></i> Application type</a>
					<ul>
						<li><a href="add-apptype.php">Add Application Type</a></li>
						<li><a href="manage-apptype.php">Manage Application Type</a></li>
					</ul>
				</li>
					<li><a href="#"><i class="fa fa-desktop"></i> Houses</a>
					<ul>
						<li><a href="create-house.php">Add  Area</a></li>
						<li><a href="manage-houses.php">Manage Area</a></li>
					</ul>
				</li>

				<li><a href="registration.php"><i class="fa fa-user"></i>Applicant Registration</a></li>
				<li><a href="manage-applicants.php"><i class="fa fa-users"></i>Manage Applicants</a></li>
				

			
		</nav>